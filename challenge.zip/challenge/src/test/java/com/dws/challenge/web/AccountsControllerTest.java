package com.dws.challenge.web;

import com.dws.challenge.domain.Account;
import com.dws.challenge.exception.AccountNotFoundException;
import com.dws.challenge.exception.DuplicateAccountIdException;
import com.dws.challenge.exception.InsufficientFundsException;
import com.dws.challenge.service.AccountsService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import java.math.BigDecimal;


class AccountsControllerTest {

    @Mock
    private AccountsService accountsService;

    @InjectMocks
    private AccountsController accountsController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(accountsController).build();
    }

    @Test
    void createAccount_Success() throws Exception {
        Account account = new Account("123", new BigDecimal("1000"));

        mockMvc.perform(post("/v1/accounts")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(account)))
                .andExpect(status().isCreated());

     //   verify(accountsService, times(1)).createAccount(account);
    }

    @Test
	void createAccount_DuplicateAccountIdException() throws Exception {
		String accountJson = "{\"accountId\":\"123\",\"balance\":1000}";

		doThrow(new DuplicateAccountIdException("Account id 123 already exists")).when(accountsService)
				.createAccount(any(Account.class));

		mockMvc.perform(post("/v1/accounts").contentType(MediaType.APPLICATION_JSON).content(accountJson))
				.andExpect(status().isBadRequest()).andExpect(content().string("Account id 123 already exists"));
	}



    @Test
    void getAccount_Success() throws Exception {
        Account account = new Account("123", new BigDecimal("1000"));
        when(accountsService.getAccount("123")).thenReturn(account);

        mockMvc.perform(get("/v1/accounts/123")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{\"accountId\":\"123\",\"balance\":1000}"));
        verify(accountsService, times(1)).getAccount("123");
    }

    @Test
    void getAccount_NotFound() throws Exception {
        when(accountsService.getAccount("123")).thenReturn(null);

        mockMvc.perform(get("/v1/accounts/123")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(accountsService, times(1)).getAccount("123");
    }

    @Test
    void transferMoney_Success() throws Exception {
        TransferRequest transferRequest = new TransferRequest();
        transferRequest.setAccountFromId("123");
        transferRequest.setAccountToId("456");
        transferRequest.setAmount(new BigDecimal("100"));

        doNothing().when(accountsService).transferMoney("123", "456", new BigDecimal("100"));

        mockMvc.perform(post("/v1/accounts/transfer")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(transferRequest)))
                .andExpect(status().isOk())
                .andExpect(content().string("Transfer successful"));

        verify(accountsService, times(1)).transferMoney("123", "456", new BigDecimal("100"));
    }

    @Test
    void transferMoney_AccountNotFound() throws Exception {
        TransferRequest transferRequest = new TransferRequest();
        transferRequest.setAccountFromId("123");
        transferRequest.setAccountToId("456");
        transferRequest.setAmount(new BigDecimal("100"));

        doThrow(new AccountNotFoundException("One or both accounts not found")).when(accountsService)
                .transferMoney("123", "456", new BigDecimal("100"));

        mockMvc.perform(post("/v1/accounts/transfer")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(transferRequest)))
                .andExpect(status().isNotFound())
                .andExpect(content().string("One or both accounts not found"));

        verify(accountsService, times(1)).transferMoney("123", "456", new BigDecimal("100"));
    }

    @Test
    void transferMoney_InsufficientFunds() throws Exception {
        TransferRequest transferRequest = new TransferRequest();
        transferRequest.setAccountFromId("123");
        transferRequest.setAccountToId("456");
        transferRequest.setAmount(new BigDecimal("100"));

        doThrow(new InsufficientFundsException("Insufficient funds")).when(accountsService)
                .transferMoney("123", "456", new BigDecimal("100"));

        mockMvc.perform(post("/v1/accounts/transfer")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(transferRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Insufficient funds"));

        verify(accountsService, times(1)).transferMoney("123", "456", new BigDecimal("100"));
    }
}
