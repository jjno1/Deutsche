package com.dws.challenge.service;

import com.dws.challenge.domain.Account;
import com.dws.challenge.exception.AccountNotFoundException;
import com.dws.challenge.exception.InsufficientFundsException;
import com.dws.challenge.repository.AccountsRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class AccountsServiceTest {

    @Mock
    private AccountsRepository accountsRepository;

    @Mock
    private NotificationService notificationService;

    @InjectMocks
    private AccountsService accountsService;

    private Account accountFrom;
    private Account accountTo;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        accountFrom = new Account("123", new BigDecimal("1000"));
        accountTo = new Account("456", new BigDecimal("500"));
    }

    @Test
    void transferMoney_successfulTransfer() {
        when(accountsRepository.getAccount("123")).thenReturn(accountFrom);
        when(accountsRepository.getAccount("456")).thenReturn(accountTo);

        accountsService.transferMoney("123", "456", new BigDecimal("200"));

        verify(notificationService).notifyAboutTransfer(accountFrom, "Transferred 200 to account 456");
        verify(notificationService).notifyAboutTransfer(accountTo, "Received 200 from account 123");
        assert accountFrom.getBalance().compareTo(new BigDecimal("800")) == 0;
        assert accountTo.getBalance().compareTo(new BigDecimal("700")) == 0;
    }

    @Test
    void transferMoney_negativeAmount() {
        assertThrows(IllegalArgumentException.class, () ->
                accountsService.transferMoney("123", "456", new BigDecimal("-100")));
    }

    @Test
    void transferMoney_insufficientFunds() {
        when(accountsRepository.getAccount("123")).thenReturn(accountFrom);
        when(accountsRepository.getAccount("456")).thenReturn(accountTo);

        assertThrows(InsufficientFundsException.class, () ->
                accountsService.transferMoney("123", "456", new BigDecimal("1100")));
    }

    @Test
    void transferMoney_accountNotFound() {
        when(accountsRepository.getAccount("123")).thenReturn(null);

        assertThrows(AccountNotFoundException.class, () ->
                accountsService.transferMoney("123", "456", new BigDecimal("100")));
    }
}
