package com.dws.challenge.service;

import com.dws.challenge.domain.Account;
import com.dws.challenge.exception.InsufficientFundsException;
import com.dws.challenge.repository.AccountsRepository;
import lombok.extern.slf4j.Slf4j;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public abstract class TransferService {
	
	private static final Logger log = LoggerFactory.getLogger(TransferService.class);

    private final AccountsRepository accountsRepository;
    private final NotificationService notificationService;

    @Autowired
    public TransferService(AccountsRepository accountsRepository, NotificationService notificationService) {
        this.accountsRepository = accountsRepository;
        this.notificationService = notificationService;
    }

    //Method to transfer money between accounts
    public void transferMoney(String accountFromId, String accountToId, BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Transfer amount must be positive");
        }

        Account accountFrom = accountsRepository.getAccount(accountFromId);
        Account accountTo = accountsRepository.getAccount(accountToId);

        //thread safety
        synchronized (getOrderedLocks(accountFrom, accountTo)) {
            if (accountFrom.getBalance().compareTo(amount) < 0) {
                throw new InsufficientFundsException("Insufficient balance in account: " + accountFromId);
            }

            //transfer operation
            accountFrom.setBalance(accountFrom.getBalance().subtract(amount));
            accountTo.setBalance(accountTo.getBalance().add(amount));

            //notification sender
            notificationService.notifyAboutTransfer(accountFrom, "Transferred " + amount + " to account " + accountToId);
            notificationService.notifyAboutTransfer(accountTo, "Received " + amount + " from account " + accountFromId);
        }

        log.info("Transfer of {} from {} to {} completed", amount, accountFromId, accountToId);
    }

    private Object[] getOrderedLocks(Account account1, Account account2) {
        return account1.getAccountId().compareTo(account2.getAccountId()) < 0
                ? new Object[]{account1, account2}
                : new Object[]{account2, account1};
    }
    
    public abstract void transferFunds(String accountFrom, String accountTo, BigDecimal amount);

}
