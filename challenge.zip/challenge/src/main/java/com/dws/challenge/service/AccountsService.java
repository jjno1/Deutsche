package com.dws.challenge.service;

import com.dws.challenge.domain.Account;
import com.dws.challenge.exception.AccountNotFoundException;
import com.dws.challenge.exception.InsufficientFundsException;
import com.dws.challenge.repository.AccountsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class AccountsService {

    private static final Logger log = LoggerFactory.getLogger(AccountsService.class);
    private final AccountsRepository accountsRepository;
    private final NotificationService notificationService;

    @Autowired
    public AccountsService(AccountsRepository accountsRepository, NotificationService notificationService) {
        this.accountsRepository = accountsRepository;
        this.notificationService = notificationService;
    }
    
    public void createAccount(Account account) {
        this.accountsRepository.createAccount(account);
      }

      public Account getAccount(String accountId) {
        return this.accountsRepository.getAccount(accountId);
      }


    public void transferMoney(String fromAccountId, String toAccountId, BigDecimal amount) {
        // Ensure the amount is positive
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("The amount to transfer must be a positive number.");
        }

        // Synchronized block for thread safety
        synchronized (this) {
            Account fromAccount = accountsRepository.getAccount(fromAccountId);
            Account toAccount = accountsRepository.getAccount(toAccountId);

            // Check if accounts exist
            if (fromAccount == null || toAccount == null) {
                throw new AccountNotFoundException("One or both accounts not found");
            }

            // Ensure sufficient funds
            if (fromAccount.getBalance().compareTo(amount) < 0) {
                throw new InsufficientFundsException("Insufficient funds");
            }

            // Perform the transfer
            fromAccount.setBalance(fromAccount.getBalance().subtract(amount));
            toAccount.setBalance(toAccount.getBalance().add(amount));

            // Update accounts in the repository
            accountsRepository.updateAccount(fromAccount);
            accountsRepository.updateAccount(toAccount);

            // Send notifications
            notificationService.notifyAboutTransfer(fromAccount, "Transferred " + amount + " to account " + toAccountId);
            notificationService.notifyAboutTransfer(toAccount, "Received " + amount + " from account " + fromAccountId);

            log.info("Transfer successful: {} transferred {} to {}", fromAccountId, amount, toAccountId);
        }
    }
}
