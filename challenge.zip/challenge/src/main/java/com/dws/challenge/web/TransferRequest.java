package com.dws.challenge.web;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class TransferRequest {

    @NotNull
    @NotEmpty
    private String accountFromId;

    @NotNull
    @NotEmpty
    private String accountToId;

    @NotNull
    @Min(value = 1, message = "Transfer amount must be greater than zero.")
    private BigDecimal amount;

	public void setAccountFromId(String accountFromId) {
		this.accountFromId = accountFromId;
	}

	public void setAccountToId(String accountToId) {
		this.accountToId = accountToId;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	
	

	 
}
